library(broom)
library(lsmeans)
library(plyr)
library(tidyverse)
library(stringr)
library(magrittr)
library(ggstance)
library(forcats)

# set working directory to wheverever you unzipped these file

d1 <- "jeps_replication_data.csv" %>% 
  readr::read_csv() %>% 
  dplyr::slice(-c(1:2)) %>%  
  dplyr::rename("podesta no correction_1"  = Q77_1)

# These are the correction labels

ct <- c(
  "pizzagate",
  "podesta",
  "vermont",
  "scaramucci",
  "pedophiles",
  "birth cert"
  )

# This is the first modelling table
ct_long <- ct %>% 
  map_df(function(i)
    d1 %>% 
      dplyr::select(Q34_1, Q19,
             contains(i)) %>%
      tidyr::gather(corr, ans, -c(Q34_1, Q19), na.rm = T)) %>% 
  dplyr::arrange(Q34_1) %>% 
  dplyr::filter(ans %>% 
           str_to_lower %>% 
           str_detect("disagree|agree")) %>% 
  dplyr::mutate(ideo = Q19 %>% 
           str_to_lower %>% 
           str_extract("conservative|liberal|moderate") %>% 
           factor(c("conservative",
                    "moderate",
                    "liberal")),
         ans_num = ans %>%
           plyr::mapvalues(c("Strongly Agree",
                             "Agree",
                             "Neither Agree nor Disagree",
                             "Disagree",
                             "Strongly disagree"),
                           5:1) %>% 
           as.numeric,
         issue = corr %>% 
           str_extract(ct %>% 
                         str_c(collapse = "|")),
         corr = corr %>% 
           str_replace_all(ct %>% 
                             str_c(collapse = "|"),
                           "") %>% 
           str_sub( , -3) %>% 
           str_trim(side = "both"),
         corr = corr  %>% 
           plyr::mapvalues(c("correction",
                       "correctio",
                       "no correctio",
                       "no correc",
                       
                       "green correc",
                       "no correct",
                       "post correct",
                       "no correction"),
                     
                     c("correction",
                       "correction",
                       "no correction",
                       "no correction",
                       
                       "green correction",
                       "no correction",
                       "wapost correction",
                       "no correction")),
         issue = issue  %>%  
           plyr::mapvalues(c("pizzagate",
                       "podesta",
                       "vermont",
                       "scaramucci",
                       "pedophiles",
                       "birth cert"),
                     c("DC pizza restaurant concealed sex dungeon used by Democratic elites",
                       "John Podesta implicated in disappearance of Madeleine McCann",
                       "Russian government hacks Vermont power plant",
                       "Anthony Scaramucci subject of Senate Russia investigation",
                       "President Trump orders unprecedented crackdown on sex trafficking",
                       "President Obama fakes birth certificate")),
         Q34_1 = Q34_1 %>% 
           str_replace_all("&gt;&gt;  ", "") %>% 
           str_trim,
         corr = corr %>% 
           factor(c("green correction" ,
                    "wapost correction",
                    "correction",
                    "no correction")
                  ),
         corr2 = corr %>%
           plyr::mapvalues(corr %>% 
                       unique,
                     c("correction",
                       "no correction",
                       "correction",
                       "correction")) %>% 
           factor(c("no correction",
                    "correction"))
         )

# This is reversing the one item where factual corrections were indicated by higher
ct_long$ans_num[ct_long$issue  %>% 
                  equals("President Obama fakes birth certificate")] %<>%
  plyr::mapvalues(1:5, 5:1)

# Here, we compute correction effect 
lt4 <- ct_long %>% 
  ddply(.(issue),
        function(i)
          lm(ans_num ~ corr2, 
             data = i) %>% 
          tidy) %>% 
  dplyr::filter(term %>% 
           str_detect("corr2")) %>% 
  dplyr::select(-term, -statistic) %>% 
  dplyr::mutate(yax = "Overall",
         type = "Overall effects") %>% 
  # now, ideological differences
  rbind.fill(
    ct_long %>% 
      ddply(.(issue),
            function(i)
              lm(ans_num ~ corr2*ideo, 
                 data = i) %>% 
              lsmeans(~corr2 | ideo) %>% 
              pairs(rev = T) %>% 
              tidy) %>% 
      dplyr::select(-level1, -level2, -statistic, -df) %>% 
      tbl_df %>% 
      dplyr::rename("yax" = ideo) %>% 
      dplyr::mutate(type = "Effects by ideology")
  ) %>% 
  # now, differences by ideology
  rbind.fill(
    ct_long %>% 
      dlply(
        .(issue),
        function(i)
          lm(ans_num ~ corr2*ideo,
             data = i) %>%
          lsmeans(~corr2 * ideo) %>% 
          contrast(method = "revpairwise") %>% 
          contrast(method = "revpairwise", adjust = "fdr")
            ) %>% 
      map_df(
        function(i)
          i %>%
          summary %>% 
          as.data.frame() %>% 
          dplyr::mutate(contrast = contrast %>% 
                   str_trim)
      ) %>%
      tbl_df %>% 
      dplyr::filter(contrast %>%
               is_in(c("correction,moderate - no correction,moderate - correction,conservative - no correction,conservative",
                       "correction,liberal - no correction,liberal - correction,moderate - no correction,moderate"))
             ) %>% 
      dplyr::select(-df, -t.ratio) %>% 
      dplyr::rename("yax" = contrast,
             "std.error" = SE) %>% 
      dplyr::mutate(type = "Difference in correction effects",
             yax = c(
               "moderate - conservative",
               "moderate - liberal"
             ) %>% 
               rep(times = 6),
             issue = ct_long$issue %>% 
               factor %>% 
               levels %>% 
               rep(each = 2)
      )
  ) %>% 
  tbl_df

# Getting the contrast pointing in a consistent fashion
lt4$estimate[lt4$yax == "moderate - liberal"] %<>%
  multiply_by(-1)


lt4$type %<>% 
  factor(lt4$type %>% 
           unique)

lt4$estimate %<>% 
  as.numeric()

# the 95% confidence interval

lt4$lo <- lt4$estimate %>% 
  subtract(lt4$std.error %>% 
             multiply_by(1.96))

lt4$hi <- lt4$estimate %>% 
  add(lt4$std.error %>%
        multiply_by(1.96))


lt4$yax %<>%
  factor(lt4$yax %>%
           unique)


# the labels for plot

lt4$lab <- 
  ifelse(
    lt4$estimate %>% 
      sign %>% 
      equals(-1),
    lt4$estimate %>%
      round(2) %>%
      as.character %>%
      str_pad(width = 5, 
              side = "right", 
              pad = "0") %>% 
      str_replace_all(fixed("0."),
                      "."),
    lt4$estimate %>%
      round(2) %>%
      as.character %>%
      str_pad(width = 4, 
              side = "right", 
              pad = "0") %>% 
      str_replace_all(fixed("0."),
                      ".")
  )

# Cleaning up a label
lt4$lab[lt4$lab == "00000"] <- 0

# appending significance stars
lt4$lab2 <- lt4$lab %>% 
  str_c(
    c("***",
      "**",
      "*",
      "") %>% 
      extract(lt4$p.value %>%
                findInterval(
                  c(-Inf, .001, .01, .05, Inf)
                )
      )
  )

# mapping significance to shapes
lt4$sig <- lt4$p.value %>% 
  is_less_than(.05) %>% 
  ifelse("Significant p < .05",
         "Insignificant p >= .05")

# Ordering the issues
lt4$issue %<>% 
  factor(
    lt4 %>% 
      dplyr::filter(
        type %>% 
          equals(lt4$type %>% 
                   levels %>%
                   extract2(1)
          )
      ) %>% 
      dplyr::arrange(estimate) %>% 
      use_series(issue)
  )

# ordering the row facets
lt4$type %<>% 
  plyr::mapvalues(lt4$type %>% 
              levels %>% 
              extract(3),
            c("Difference in correction effects by ideology")) %>% 
  factor(
    lt4$type %>% 
      levels %>% 
      extract(-3) %>% 
      c("Difference in correction effects by ideology")
  )

# this produces figure 1
lt4 %>% 
  tbl_df %>% 
  ggplot() +
  geom_vline(xintercept = 0,
             linetype = 2) +
  geom_label(aes(estimate, yax, label = lab2), 
             label.padding = unit(.125, units = "lines"), 
             nudge_y = .25,
             # vjust = -1,
             label.size = NA,
             fill = "grey96",
             fontface = "italic",
             size = 2.25) +
  geom_linerangeh(
    aes(y = yax, xmin = lo, xmax = hi)) +
  geom_point(aes(estimate, yax,
                 shape = sig),
             color = "grey5",
             fill = "grey96") +
  scale_shape_manual(values = c(16, 21) %>% 
                       rev,
                     guide = guide_legend(reverse = T,
                                          override.aes = list(size = 3))) +
  scale_y_discrete(
    breaks = lt4$yax %>% 
      levels,
    labels = lt4$yax %>% 
      levels %>% 
      str_to_title
  ) +
  facet_grid(type ~ issue, 
             space = "free_y",
             scales = "free_y",
             labeller = label_wrap_gen(width = 17)) +
  labs(x = "Correction effect(difference on 5pt agreement scale).\nNegative values indicate factual correction.",
       y = "",
       shape = "",
       caption = "***p < .001, **p < .01, *p < .05"
  ) +
  theme_minimal() +
  theme(legend.text = element_text(size = 11),
        plot.caption = element_text(face = "italic"),
        plot.title = element_text(face = "bold",
                                  hjust = 0), 
        panel.background = element_rect(color = "grey96", fill = "grey96"),
        strip.text.y = element_text(angle = 0),
        strip.background = element_rect(color = "grey96", fill = "grey96"),
        panel.grid = element_blank(),
        legend.position = "bottom",
        legend.margin = margin(t = -.35, unit = "cm")) 


# Table 1--correction effects and correction effect by ideology
library(stargazer)

ct_long$issue %<>% 
  factor(ct_long$issue %>%
           factor %>%
           levels %>%
           extract(
             c(2, 1, 3, 4, 5, 6)
             )
  )

ll3 <- ct_long %>% 
  dlply(.(issue),
        function(i)
          map(
            str_c("ans_num ~ ",
                  c("corr2",
                    "corr2*ideo")
                  ),
            function(j)
              lm(as.formula(j), i)
            )
        ) %>%
  flatten 

ll4 <- ll3 %>% 
  extract(seq(2, 12, 2)) %>% 
  map(function(i)
    i %>%
      lsmeans(~corr2|ideo) %>% 
      pairs(reverse = T) %>% 
      tidy %>% 
      dplyr::mutate(estimate = 
               str_c(
                 estimate %>% 
                   round(2) %>% 
                   as.character %>% 
                   str_replace("0.", "."),
                 c("***",
                   "**",
                   "*",
                   "") %>% 
                   extract(
                     findInterval(
                       p.value,
                       c(-Inf, 
                         .001,
                         .01,
                         .05,
                         Inf)
                       )
                     )
                 )
             )
  )

ll3 %>% 
  stargazer(
    dep.var.caption = "",
    dep.var.labels = "", 
    omit = "Constant",
    column.labels = 
      c("Pizzagate",
        "Scaramucci/Russia",
        "Podesta Brothers",
        "Obama Birth Certificate",
        "Trump Pedophilia Crackdown",
        "Russia Power Hack"),
    column.separate =
      c(2, 2, 2, 2, 2, 2),
    keep.stat = c("n",
                  "adj.rsq",
                  "rsq"),
    initial.zero = F,
    digits = 2,
    covariate.labels = 
      c("Corr.",
        "Mod.",
        "Lib.",
        "Corr(Mod",
        "Corr*Lib",
        "Constant"),
    type = "text",
    add.lines = list(c("Corr. eff. (Cons)", 
                       "", ll4[[1]]$estimate[[1]],
                       "", ll4[[2]]$estimate[[1]],
                       "", ll4[[3]]$estimate[[1]] %>% 
                         str_replace("-.8", "-.80"),
                       "", ll4[[4]]$estimate[[1]],
                       "", ll4[[5]]$estimate[[1]],
                       "", ll4[[6]]$estimate[[1]]
                       ),
                     c("(Mod)", 
                       "", ll4[[1]]$estimate[[2]],
                       "", ll4[[2]]$estimate[[2]],
                       "", ll4[[3]]$estimate[[2]],
                       "", ll4[[4]]$estimate[[2]],
                       "", ll4[[5]]$estimate[[2]],
                       "", ll4[[6]]$estimate[[2]]
                     ),
                     c("(Lib)", 
                       "", ll4[[1]]$estimate[[3]] %>% 
                         str_replace("-.5", "-.50"),
                       "", ll4[[2]]$estimate[[3]],
                       "", ll4[[3]]$estimate[[3]] %>% 
                         str_replace("-.7", "-.70"),
                       "", ll4[[4]]$estimate[[3]],
                       "", ll4[[5]]$estimate[[3]],
                       "", ll4[[6]]$estimate[[3]]
                       )
                     )
    )
                       

# These are the replication of table 2
d2 <- "jeps_replication_data.csv" %>% 
  readr::read_csv() %>% 
  dplyr::slice(-c(1:2)) %>%  
  dplyr::rename("podesta no correction_1"  = Q77_1)


d3 <- d2 %>% 
  dplyr::select(Q34_1, Q19, starts_with("vermont")) %>% 
  dplyr::slice(-1) %>% 
  tidyr::gather(cond, ans, contains("vermont")) %>% 
  dplyr::filter(ans %>%
           is.na %>% 
           not) %>% 
  dplyr::mutate(ideo = Q19 %>% 
           str_to_lower %>% 
           str_extract("conservative|liberal|moderate") %>% 
           factor(c("conservative",
                    "moderate",
                    "liberal")),
         ans_num = ans %>%
           plyr::mapvalues(c("Strongly Agree",
                             "Agree",
                             "Neither Agree nor Disagree",
                             "Disagree",
                             "Strongly disagree"),
                           5:1) %>% 
           as.numeric) %>% 
  dplyr::select(-Q19, -ans) %>% 
  dplyr::mutate(cond = cond %>% 
           str_extract("green|post|no correctio") %>% 
           factor(c("no correctio",
                    "green",
                    "post")),
         cond2 = cond %>% 
           str_detect("no correctio") %>% 
           ifelse("no correction", "correction") %>% 
           factor(c("no correction",
                    "correction")))

lm_list <- str_c(
  "ans_num ~ ",
c("cond",
  "cond*ideo",
  "cond2",
  "cond2*ideo")
) %>% 
  map(
    ~lm(., data = d3)
  )

library(stargazer)

ls2 <- lsmeans(lm_list[[2]], ~cond|ideo) %>% 
  pairs %>% 
  tidy %>% 
  dplyr::filter(level1 == "no correctio ") %>% 
  dplyr::mutate(lab = estimate %>% 
           round(2) %>%
           multiply_by(-1) %>% 
           str_replace(fixed("0."), ".") %>% 
           str_c(c("***",
                   "**",
                   "*",
                   "") %>%
                   extract(p.value %>% 
                             findInterval(c(-Inf,
                                            .001,
                                            .01,
                                            .05,
                                            Inf)))))

ls4 <- lsmeans(lm_list[[4]], ~cond2|ideo) %>% 
  pairs %>% 
  tidy %>% 
  # dplyr::filter(level1 == "no correctio ") %>% 
  dplyr::mutate(lab = estimate %>% 
           round(2) %>%
           multiply_by(-1) %>% 
           str_replace(fixed("0."), ".") %>% 
           str_c(c("***",
                   "**",
                   "*",
                   "") %>%
                   extract(p.value %>% 
                             findInterval(c(-Inf,
                                            .001,
                                            .01,
                                            .05,
                                            Inf)))))


ls2.5 <- lsmeans(lm_list[[2]], ~cond|ideo) %>% 
  pairs %>%
  pairs %>% 
  tidy %>%
  dplyr::slice(c(1, 4, 7)) %>% 
  dplyr::mutate(lab = estimate %>% 
           round(2) %>%
           multiply_by(-1) %>% 
           str_replace(fixed("0."), ".") %>% 
           str_c(c("***",
                   "**",
                   "*",
                   "") %>%
                   extract(p.value %>% 
                             findInterval(c(-Inf,
                                            .001,
                                            .01,
                                            .05,
                                            Inf)))))

lm_list %>% 
  stargazer(
    dep.var.caption = "",
    dep.var.labels = "", 
    model.numbers = FALSE,
    column.labels = c("Russia Hacks Power Grid"),
    column.separate = 4,
    add.lines = list(c("Auxillary Quantities: Correction Effects by ideology"),
                     c("Greenwald (Conservative)", "", ls2$lab[[1]], "", ""),
                     c("Greenwald (Moderate)", "", ls2$lab[[3]], "", ""),
                     c("Greenwald (Liberal)", "", ls2$lab[[5]], "", ""),
                     c("WaPo (Conservative)", "", ls2$lab[[2]], "", ""),
                     c("WaPo (Moderate)", "", ls2$lab[[4]], "", ""),
                     c("WaPo (Liberal)", "", ls2$lab[[6]], "", ""),
                     c("Conservative", "", "", "", ls4$lab[1]),
                     c("Moderate", "", "", "", ls4$lab[2]),
                     c("Liberal", "", "", "", ls4$lab[3]),
                     c("Difference in Correction Effects by ideology"),
                     c("Wapo - Greenwald (Cons)", "",  ls2.5$lab[1]),
                     c("Wapo - Greenwald (Mod)", "", ls2.5$lab[2]),
                     c("Wapo - Greenwald (Lib)", "", ls2.5$lab[3])),
    no.space = T,
    covariate.labels = 
      c("Greenwald correction",
        "Washington Post correction",
        "Moderate",
        "Liberal",
        "Greenwald x Moderate",
        "Washington Post x Moderate",
        "Greenwald x Liberal",
        "Washington Post x Liberal",
        "Overall correction x Moderate",
        "Overall correction x Liberal",
        "Overall correction"),
    type = "text", 
    keep = "[^Constant]", 
    digits = 2,
    initial.zero = F, 
    keep.stat = c("n",
                  "rsq")
    )

# The balance table

d4 <- "jeps_replication_data.csv" %>% 
  readr::read_csv() %>% 
  dplyr::slice(-c(1:2)) %>%  
  dplyr::rename("podesta no correction_1"  = Q77_1)

d5 <- d4 %>% 
  dplyr::select(Q34_1,
         FL_67_DO:FL_82_DO) %>% 
  dplyr::slice(-1) %>% 
  tidyr::gather(item, exp, -Q34_1, na.rm = T) %>% 
  dplyr::arrange(Q34_1) %>% 
  dplyr::mutate(corr = exp %>% 
           str_detect("nocorrection") %>%
           not %>% 
           as.numeric) %>% 
  group_by(Q34_1) %>% 
  summarize(tote = corr %>% sum) %>% 
  dplyr::mutate(tote = tote %>% 
           plyr::mapvalues(3, 2))

d6 <- d4 %>% 
  dplyr::slice(-1) %>% 
  dplyr::select(Q34_1, Q5:Q19, Q23) %>% 
  dplyr::select(-Q15) %>% 
  dplyr::mutate(Q5 = Q5 %>% 
           as.numeric,
         Q7 = Q7 %>% 
           plyr::mapvalues(c("Associate degree",
                       "Attended high school but did not graduate",
                       "Attended pre-high school but not high school",
                       "Bachelors degree",
                       "High school graduate (hold Diploma)", 
                       "Masters degree",
                       "No formal education",
                       "Professional or Doctorate degree",
                       "Some college, no degree"),
                     c("HSD or less",
                       "Some college",
                       "BA +") %>% 
                       extract(c(2, 1, 1, 3, 1, 3, 1, 3, 2))) %>% 
           factor(c("HSD or less",
                    "Some college",
                    "BA +")),
         Q9 = Q9 %>% 
           fct_lump(n = 3) %>% 
           plyr::mapvalues(c("Black, Non-Hispanic",
                       "Other, Non-Hispanic",
                       "White, Non-Hispanic",
                       "Other"),
                     c("Black",
                       "Other",
                       "White",
                       "Hispanic")),
         Q17 = Q17 %>%
           str_to_lower %>% 
           str_extract("democrat|republican|independent"),
         Q19 = Q19 %>%
           str_to_lower %>% 
           str_extract("liberal|moderate|conservative"),
         Q23 = case_when(
           
           Q23 %>% 
             str_detect("Clinton") ~ "Clinton",
           Q23 %>% 
             str_detect("Trump") ~ "Trump",
           
           TRUE ~ "Other"
         ),
         Q13 = Q13 %>% 
           as.factor %>% 
           plyr::mapvalues(d1$Q13 %>%
                       unique,
                     d1$Q13 %>%
                       unique %>% 
                       map(~str_extract_all(., "\\d{1,3},\\d{3}") %>% 
                             unlist %>% 
                             str_replace_all(",", "") %>% 
                             as.numeric %>% 
                             mean) %>%
                       unlist) %>% 
           as.character %>% 
           as.numeric) %>% 
  dplyr::rename("age" = Q5,
         "education" = Q7,
         "race" = Q9,
         "gender" = Q11,
         "income" = Q13,
         "party" = Q17,
         "ideology" = Q19,
         "presvote" = Q23) %>% 
  left_join(d5) 

d2_num <- d6 %>% 
  dplyr::select(Q34_1, tote, age, income) %>% 
  tidyr::gather(variable, value, -c(Q34_1, tote)) %>% 
  group_by(tote, variable) %>% 
  summarize(mu = value %>% 
              mean) %>% 
  spread(variable, mu) %>% 
  dplyr::mutate(income = income %>% 
           round %>% 
           prettyNum(big.mark = ",") %>% 
           str_c("$", .),
         age = age %>% 
           round(1)) %>% 
  tidyr::gather(var_val, val, -tote) %>%
  ungroup %>% 
  dplyr::mutate(tote = str_c("y", 
                      tote)) %>% 
  dplyr::filter(tote != "y3") %>% 
  spread(tote, val)

dres <- d6 %>% 
  dplyr::select(-c(age, income)) %>% 
  tidyr::gather(variable, value, -c(Q34_1, tote)) %>% 
  group_by(tote, variable, value) %>% 
  tally %>% 
  dplyr::mutate(value = value %>% 
           factor(c(
             "HSD or less",
             "Some college",
             "BA +",
             "Female",
             "Male",
             "liberal",
             "moderate",
             "conservative",
             "democrat",
             "independent",
             "republican",
             "Clinton",
             "Trump",
             "Other",
             "Black",
             "Hispanic",
             "White"))) %>% 
  dplyr::arrange(tote, variable, value) %>% 
  dplyr::mutate(prop = n %>% 
           divide_by(n %>% 
                       sum) %>% 
           multiply_by(100) %>% 
           round) %>% 
  dplyr::select(-n) %>% 
  unite(var_val, c(variable, value), sep = "_") %>% 
  dplyr::mutate(var_val = var_val %>% 
           factor(var_val %>% 
                    unique)) %>%
  ungroup %>% 
  dplyr::mutate(tote = str_c("y", tote)) %>% 
  spread(tote, prop) %>% 
  rbind(d2_num) %>%
  separate(var_val, 
           sep = "_",
           into = 
             c("category",
               "val")
           ) %>% 
  dplyr::mutate(category = c(
    "Education",
     "", "",
     "Gender",
     "",
     "Ideology",
     "", "",
     "Party",
     "", "",
     "2016 Vote",
     "", "",
     "Race",
     "", "", "",
     "Age",
     "Income"),
    val = val %>% 
      is.na %>% 
      ifelse("", val) %>% 
      str_to_title
    ) %>% 
  dplyr::rename_(
    .dots = setNames(str_c("y", 0:2),
                     str_c("corr_",
                           0:2)
                     )
  )

# the measures of association

al <- c("education",
        "gender",
        "ideology",
        "party",
        "presvote",
        "race") %>% 
  map_df(function(i)
    d6 %>% 
      dplyr::select_(.dots = c(i, "tote")) %>% 
      table %>% 
      chisq.test %>% 
      tidy) %>% 
  dplyr::mutate(lab = 
           str_c(
             "X^2 = ",
             statistic %>%
               round(2) %>%
               as.character %>%
               str_replace("0.", "."),
             ", p = ",
             p.value %>% 
               round(2) %>% 
               str_sub(2) %>% 
               str_pad(width = 3, side = "right", pad = "0")
             )
         )

al2 <- c("age",
         "income") %>% 
  map_df(
    function(i)
      
      aov(str_c("tote ~ ", i) %>% 
            as.formula,
          data = d6
      ) %>% 
      tidy
    ) %>% 
  na.omit %>% 
  dplyr::mutate(lab = str_c(
    "F(1, 2102) = ",
    statistic %>% 
      round(2) %>% 
      as.character %>%
      str_sub(2),
    ", p = ",
    p.value %>% 
      round(2) %>% 
      as.character %>% 
      str_sub(2)
    )
  )

dres$association <- 
  c(al$lab, 
    "") %>%
  extract(
    c(1, 7, 7,
      2, 7,
      3, 7, 7,
      4, 7, 7,
      5, 7, 7,
      6, 7, 7, 7)
    ) %>% 
  c(al2$lab)

dres
