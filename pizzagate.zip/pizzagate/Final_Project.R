# Header ------------------------------------------------------------------

# File Name: 	  	  Final_Project
# File Purpose:  	  R code for Project 2
# Author: 	    	  Anna Callahan (University of Pennsylvania)
# Date Created:     2020/08/04
# Notes:            Data is from Harvard Dataverse

# Install Packages & Set WD ---------------------------------------------------

getwd()
setwd("/Users/annacallahan/Documents/Intro to Data Science/Project 2")

# Load packages
library(tidyverse)
library(stargazer)
library(ggeffects)
library(dplyr)

# Data Cleaning  ---------------------------------------------------

# Load data
csvobj <- "jeps_replication_data.csv"
df <- read.csv(csvobj)

# Examine data
dim(df) # 2107 x 161
glimpse(df)
# view(df)
colnames(df)

# Clean data - create a new df only including the necessary columns and rename
# them so we know what we're working with.

df$id <- 1:nrow(df)
df_clean <- select(df,Finished,Q5,Q7,Q9,Q11,Q17,Q19,pizzagate.correction_1,pizzagate.no.correct_1,id)
glimpse(df_clean)

dta <- df_clean %>% 
  rename(age = Q5, 
         education = Q7,
         race = Q9,
         gender = Q11,
         political_party = Q17,
         political_ideology = Q19,
         pizzagate_treatment_agreement = pizzagate.correction_1,
         pizzagate_control_agreement = pizzagate.no.correct_1,
         id = id)
colnames(dta)

# Drop first two rows b/c they are not responses
dta <- tail(dta,-2)

# Convert age to numeric
dta$age <- as.numeric(dta$age)


# Exploratory Data Analysis ---------------------------------------------------

# EDUCATION
education <- select(dta,education)
dist_ed <- as.data.frame(round(prop.table(table(education$education,useNA="ifany")) * 100,2))
# convert to factor variable
education$education <- factor(education$education,
                                levels = c("No formal education", 
                                           "Attended pre-high school but not high school",
                                           "Attended high school but did not graduate",
                                           "High school graduate (hold Diploma)",
                                           "Some college, no degree",
                                           "Associate degree",
                                           "Bachelors degree",
                                           "Masters degree",
                                           "Professional or Doctorate degree"))
education$education <- education$education %>% 
  fct_collapse(no_college_degree=c("No formal education", 
                              "Attended pre-high school but not high school",
                              "Attended high school but did not graduate",
                              "High school graduate (hold Diploma)",
                              "Some college, no degree"),
               associate_degree=c("Associate degree"),
               bachelors_degree=c("Bachelors degree"),
               masters_degree=c("Masters degree"),
               doctorate=c("Professional or Doctorate degree"))
# plot
ggplot(data = education) +
  geom_bar(mapping = aes(x = education, fill=education)) +
  labs(title = "Distribution of Survey Respondants by Education Level",
       caption = "Source: A Survey Experiment Correcting Fake News, via Harvard Dataverse")
table(education)

# GENDER
gender <- select(dta,gender)
dist_g <- round(prop.table(table(gender$gender,useNA="ifany")) * 100,2)
dist_g # Slightly fewer women but very close

# RACE
race <- select(dta,race)
dist_r <- round(prop.table(table(race$race,useNA="ifany")) * 100,2)
dist_r 
# plot
ggplot(data = race) +
  geom_bar(mapping = aes(x = race, fill=race)) +
  labs(title = "Racial Distribution of Survey Respondants",
       caption = "Source: A Survey Experiment Correcting Fake News, via Harvard Dataverse")
# Vast majority of respondents are white - about ~76%

# AGE
age <- select(dta,age)
age <- tail(age,-1) # weird, idk why that happened
ggplot(data = age) +
  geom_histogram(mapping = aes(x = age), binwidth = 4) 
# Not a normal distribution - this is positively skewed (towards younger respondents)

# POLITICAL PARTY
party <- select(dta,political_party)
# convert to factor variable
party$political_party <- factor(party$political_party,
                                  levels = c("Strong Democrat", 
                                             "Leans Democrat",
                                             "Not Strong Democrat",
                                             "Undecided/Independent/Other",
                                             "Not Strong Republican",
                                             "Leans Republican",
                                             "Strong Republican"))
dist_pp <- as.data.frame(round(prop.table(table(party$political_party,useNA="ifany")) * 100,2))
view(dist_pp)
# 50.92% of respondents are weak to strong democrats and only 28.17% identified
# as weak to strong republicans. The rest id'd as independent.
# plot the data
ggplot(data = party) +
  geom_bar(mapping = aes(x = political_party, fill=political_party)) +
  labs(title = "Distribution of Survey Respondants by Political Party",
       caption = "Source: A Survey Experiment Correcting Fake News, via Harvard Dataverse")

# POLITICAL IDEOLOGY
ideo <- select(dta,political_ideology)
dist_pi <- as.data.frame(round(prop.table(table(ideo$political_ideology,useNA="ifany")) * 100,2))
view(ideo)
# convert to factor
ideo$political_ideology <- factor(ideo$political_ideology,
                                  levels = c("Extremely liberal", 
                                             "Liberal",
                                             "Slightly liberal",
                                             "Moderate, middle of the road",
                                             "Slightly conservative",
                                             "Conservative",
                                             "Extremely conservative"))
# plot
ggplot(data = ideo) +
  geom_bar(mapping = aes(x = political_ideology, fill=political_ideology)) +
  labs(title = "Distribution of Survey Respondants by Political Ideology",
       caption = "Source: A Survey Experiment Correcting Fake News, via Harvard Dataverse")
# 51.83% identified as slightly to extremely liberal, and 27.79% identified as 
# slightly to extremely conservative. 

# summarize using stargazer
stargazer(age, 
          type = "text",
          title = "Summary")

# Set Up for Balance Testing ---------------------------------------------------

view(dta)
dta$group <- NA

# GROUP = 1 means that the respondent was in the TREATMENT GROUP
# GROUP = 0 means that the respondent was in the CONTROL GROUP

# 1. Make a dataframe with the TREATMENT responses
pt <- subset(dta, dta$pizzagate_treatment_agreement!="") # where treatment column is filled
pt$group <- 1
pt$pizzagate_control_agreement <- NA
view(pt)

# 2. Make a dataframe with the CONTROL responses
pc <- subset(dta, dta$pizzagate_control_agreement!="") # where treatment column is filled
pc$group <- 0
pc$pizzagate_treatment_agreement <- NA
view(pc)

# 3. MERGE the two dataframes
pizzagate <- rbind(pt,pc)
view(pizzagate)

# Create the outcome variable
# OUTCOME = 1 means that the respondent DID NOT BELIEVE the fake article
# OUTCOME = 0 means that the respondent DID BELIEVE the fake article
pizzagate$outcome <- NA
pizzagate$outcome[pizzagate$pizzagate_treatment_agreement=="Strongly disagree"|
                    pizzagate$pizzagate_treatment_agreement=="Disagree"|
                    pizzagate$pizzagate_control_agreement=="Strongly disagree"|
                    pizzagate$pizzagate_control_agreement=="Disagree"] <- 1
pizzagate$outcome[pizzagate$pizzagate_treatment_agreement=="Strongly Agree"|
                    pizzagate$pizzagate_treatment_agreement=="Agree"|
                    pizzagate$pizzagate_treatment_agreement=="Neither Agree nor Disagree"|
                    pizzagate$pizzagate_control_agreement=="Strongly Agree"|
                    pizzagate$pizzagate_control_agreement=="Agree"|
                    pizzagate$pizzagate_control_agreement=="Neither Agree nor Disagree"] <- 0
view(pizzagate)

# Dummy Variable Creation (DONE) ---------------------------------------------------

# EDUCATION BINARY VARIABLE SETUP
pizzagate$education <- factor(pizzagate$education,
                              levels = c("No formal education", 
                                         "Attended pre-high school but not high school",
                                         "Attended high school but did not graduate",
                                         "High school graduate (hold Diploma)",
                                         "Some college, no degree",
                                         "Associate degree",
                                         "Bachelors degree",
                                         "Masters degree",
                                         "Professional or Doctorate degree"))
pizzagate$education <- pizzagate$education %>% 
  fct_collapse(no_college_degree=c("No formal education", 
                                   "Attended pre-high school but not high school",
                                   "Attended high school but did not graduate",
                                   "High school graduate (hold Diploma)",
                                   "Some college, no degree"),
               associate_degree=c("Associate degree"),
               bachelors_degree=c("Bachelors degree"),
               masters_degree=c("Masters degree"),
               doctorate=c("Professional or Doctorate degree"))

fastDummies_ed <- data.frame(numbers = 1:nrow(pizzagate),
                           ed_levels = pizzagate$education,
                           group = pizzagate$group,
                           stringsAsFactors = FALSE)
knitr::kable(fastDummies_ed)
results_ed <- fastDummies::dummy_cols(fastDummies_ed) # now we can regress on this
view(results_ed)

# POLITICAL PARTY BINARY VARIABLE SETUP
pizzagate$political_party # we have 7 categories here
table(pizzagate$political_party)
fastDummies_pp <- data.frame(numbers = 1:nrow(pizzagate),
                             party_id = pizzagate$political_party,
                             group = pizzagate$group,
                             outcome = pizzagate$outcome,
                             stringsAsFactors = FALSE)
results_pp <- fastDummies::dummy_cols(fastDummies_pp) # now we can regress on this
view(results_pp)
colnames(results_pp)
# fix column names
colnames(results_pp)
colnames(results_pp)[which(colnames(results_pp)=="party_id_Leans Democrat")] <- "party_id_leans_democrat"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Leans Republican")] <- "party_id_leans_republican"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Undecided/Independent/Other")] <- "party_id_independent"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Strong Democrat")] <- "party_id_strong_democrat"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Strong Republican")] <- "party_id_strong_republican"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Not Strong Democrat")] <- "party_id_not_strong_democrat"
colnames(results_pp)[which(colnames(results_pp)=="party_id_Not Strong Republican")] <- "party_id_not_strong_republican"
view(results_pp)

# POLITICAL IDEOLOGY BINARY VARIABLE SETUP
pizzagate$political_ideology # we have 7 categories here
dim(table(pizzagate$political_ideology))
fastDummies_polid <- data.frame(numbers = 1:nrow(pizzagate),
                             ideology_id = pizzagate$political_ideology,
                             group = pizzagate$group,
                             stringsAsFactors = FALSE)
results_pi <- fastDummies::dummy_cols(fastDummies_polid)
view(results_pi)
# fix column names
colnames(results_pi)
colnames(results_pi)[which(colnames(results_pi)=="ideology_id_Extremely conservative")] <- "ideology_id_extremely_conservative"
colnames(results_pi)[which(colnames(results_pi)=="ideology_id_Extremely liberal")] <- "ideology_id_extremely_liberal"
colnames(results_pi)[which(colnames(results_pi)=="ideology_id_Moderate, middle of the road")] <- "ideology_id_moderate"
colnames(results_pi)[which(colnames(results_pi)=="ideology_id_Slightly conservative")] <- "ideology_id_slightly_conservative"
colnames(results_pi)[which(colnames(results_pi)=="ideology_id_Slightly liberal")] <- "ideology_id_slightly_liberal"
view(results_pi) # fixed!

# What was the breakdown?
table(pizzagate$outcome)
# NONBELIEVERS: 341
# BELIEVERS/UNSURE: 329

# How large are the treatment and control groups respectively?
table(pizzagate$group) # 357 control / 313 treatment

# What will we be balance testing?
# 1. Average age of respondents
# 2. Average educational attainment of respondent
# 3. Average political ideology of respondent
# 4. Average political party of respondent


# Balance Testing - Age Variable (DONE) ---------------------------------------------------

# AGE BALANCE TEST - DONE
# H0: There IS NO difference in average age between the treatment and control groups
# H1: There IS a difference in average age between the treatment and control groups
# We want a high p-value so that we can accept H0 and determine that randomization was successful.
AvgAge <- t.test(x = pizzagate$age[pizzagate$group==1],
                 y = pizzagate$age[pizzagate$group==0],
                 alternative = "two.sided")
AvgAge # p = 0.6595 (high -> randomization successful)

# Balance Testing - Political Party Variable (DONE) ---------------------------------------------------

# POLITICAL PARTY BALANCE TEST - STRONG REPUBLICAN
table(pizzagate$political_party)
view(results_pp)
colnames(results_pp)
# H0: There is no difference in avg number of STRONG REPUBLICANS between the treatment and control groups
# H1: There is a difference in avg number of STRONG REPUBLICANS between the treatment and control groups
AvgPartySR <- t.test(x = results_pp$party_id_strong_republican[results_pp$group==1],
                   y = results_pp$party_id_strong_republican[results_pp$group==0],
                   alternative = "two.sided")
AvgPartySR # p-value = 0.4173 (high) -> accept H0 -> randomization successful

# POLITICAL PARTY BALANCE TEST - LEANS REPUBLICAN
# H0: There is no difference in avg number of LEANS REPUBLICANS between the treatment and control groups
# H1: There is a difference in avg number of LEANS REPUBLICANS between the treatment and control groups
AvgPartyLR <- t.test(x = results_pp$party_id_leans_republican[results_pp$group==1],
                     y = results_pp$party_id_leans_republican[results_pp$group==0],
                     alternative = "two.sided")
AvgPartyLR # p-value = 0.6905 (high) -> accept H0 -> randomization successful

# POLITICAL PARTY BALANCE TEST - NOT STRONG REPUBLICAN
# H0: There is no difference in avg number of NOT STRONG REPUBLICANS between the treatment and control groups
# H1: There is a difference in avg number of NOT STRONG REPUBLICANS between the treatment and control groups
AvgPartyNSR <- t.test(x = results_pp$party_id_not_strong_republican[results_pp$group==1],
                     y = results_pp$party_id_not_strong_republican[results_pp$group==0],
                     alternative = "two.sided")
AvgPartyNSR # p-value = 0.01662 (low) -> reject H0 -> randomization UNSUCCESSFUL
table(results_pp$party_id_not_strong_republican, results_pp$group)
# Why? there are 621 of them in the control group and only 49 in the treatment group

# POLITICAL PARTY BALANCE TEST - INDEPENDENT
AvgPartyI <- t.test(x = results_pp$party_id_independent[results_pp$group==1],
                      y = results_pp$party_id_independent[results_pp$group==0],
                      alternative = "two.sided")
AvgPartyI # p-value = 0.2939 (high ish) -> accept H0 -> randomization successful!

# POLITICAL PARTY BALANCE TEST - NOT STRONG DEMOCRAT
AvgPartyNSD <- t.test(x = results_pp$party_id_not_strong_democrat[results_pp$group==1],
                    y = results_pp$party_id_not_strong_democrat[results_pp$group==0],
                    alternative = "two.sided")
AvgPartyNSD # p-value = 0.6389 (high) -> accept H0 -> randomization successful!

# POLITICAL PARTY BALANCE TEST - LEANS DEMOCRAT
AvgPartyLD <- t.test(x = results_pp$party_id_leans_democrat[results_pp$group==1],
                      y = results_pp$party_id_leans_democrat[results_pp$group==0],
                      alternative = "two.sided")
AvgPartyLD # p-value = 0.3279 (high ish) -> accept H0 -> randomization successful!

# POLITICAL PARTY BALANCE TEST - STRONG DEMOCRAT
AvgPartySD <- t.test(x = results_pp$party_id_strong_democrat[results_pp$group==1],
                     y = results_pp$party_id_strong_democrat[results_pp$group==0],
                     alternative = "two.sided")
AvgPartySD # p-value = 0.7293 (high) -> accept H0 -> randomization successful!

# Balance Testing - Educational Attainment Variable (DONE) ---------------------------------------------------

# EDUCATION BALANCE TEST

colnames(results_ed)

# H0: There IS NO difference in average education level between the treatment and control groups
# H1: There IS a difference in average education level between the treatment and control groups
# We want a high p-value so that we can accept H0 and determine that randomization was successful.
AvgNonCollege <- t.test(x = results_ed$ed_levels_no_college_degree[results_ed$group==1],
                        y = results_ed$ed_levels_no_college_degree[results_ed$group==0],
                        alternative = "two.sided")
AvgNonCollege # p = 0.25 (high -> randomization successful)


AvgAssoc <- t.test(x = results_ed$ed_levels_associate_degree[results_ed$group==1],
                        y = results_ed$ed_levels_associate_degree[results_ed$group==0],
                        alternative = "two.sided")
AvgAssoc # p = 0.465 (high -> randomization successful)

AvgBach <- t.test(x = results_ed$ed_levels_bachelors_degree[results_ed$group==1],
                   y = results_ed$ed_levels_bachelors_degree[results_ed$group==0],
                   alternative = "two.sided")
AvgBach # p = 0.4115 (high -> randomization successful)

AvgMasters <- t.test(x = results_ed$ed_levels_masters_degree[results_ed$group==1],
                  y = results_ed$ed_levels_masters_degree[results_ed$group==0],
                  alternative = "two.sided")
AvgMasters # p = 0.1842 (high enough -> randomization sort of successful)

AvgDoc <- t.test(x = results_ed$ed_levels_doctorate[results_ed$group==1],
                     y = results_ed$ed_levels_doctorate[results_ed$group==0],
                     alternative = "two.sided")
AvgDoc # p = 0.1222 (high enough -> randomization sort of successful)

# These last two p-values are probably lower because there are relatively few
# people with masters degrees and doctorates who responded

# Balance Testing - Create & Fill in Balance Matrix (DONE) ---------------------------------------------------

# Create a matrix for storing the balance test
balance_mat <- matrix(nrow = 13,
                      ncol = 3,
                      dimnames = list(c("avg_age",
                                        "avg_party_SR",
                                        "avg_party_LR",
                                        "avg_party_NSR",
                                        "avg_party_I",
                                        "avg_party_NSD",
                                        "avg_party_LD",
                                        "avg_party_SD",
                                        "avg_ed_NC",
                                        "avg_ed_AD",
                                        "avg_ed_BA",
                                        "avg_ed_MA",
                                        "avg_ed_PhD"),
                                      c("Mean Treatment","Mean Control","p-value"))
)

# Now fill it in

# AGE
balance_mat[1,1] <- AvgAge$estimate[1]
balance_mat[1,2] <- AvgAge$estimate[2]
balance_mat[1,3] <- AvgAge$p.value

# POLITICAL PARTY
balance_mat[2,1] <- AvgPartySR$estimate[1]
balance_mat[2,2] <- AvgPartySR$estimate[2]
balance_mat[2,3] <- AvgPartySR$p.value

balance_mat[3,1] <- AvgPartyLR$estimate[1]
balance_mat[3,2] <- AvgPartyLR$estimate[2]
balance_mat[3,3] <- AvgPartyLR$p.value

balance_mat[4,1] <- AvgPartyNSR$estimate[1]
balance_mat[4,2] <- AvgPartyNSR$estimate[2]
balance_mat[4,3] <- AvgPartyNSR$p.value

balance_mat[5,1] <- AvgPartyI$estimate[1]
balance_mat[5,2] <- AvgPartyI$estimate[2]
balance_mat[5,3] <- AvgPartyI$p.value

balance_mat[6,1] <- AvgPartyNSD$estimate[1]
balance_mat[6,2] <- AvgPartyNSD$estimate[2]
balance_mat[6,3] <- AvgPartyNSD$p.value

balance_mat[7,1] <- AvgPartyLD$estimate[1]
balance_mat[7,2] <- AvgPartyLD$estimate[2]
balance_mat[7,3] <- AvgPartyLD$p.value

balance_mat[8,1] <- AvgPartySD$estimate[1]
balance_mat[8,2] <- AvgPartySD$estimate[2]
balance_mat[8,3] <- AvgPartySD$p.value

# EDUCATION LEVEL
balance_mat[9,1] <- AvgNonCollege$estimate[1]
balance_mat[9,2] <- AvgNonCollege$estimate[2]
balance_mat[9,3] <- AvgNonCollege$p.value

balance_mat[10,1] <- AvgAssoc$estimate[1]
balance_mat[10,2] <- AvgAssoc$estimate[2]
balance_mat[10,3] <- AvgAssoc$p.value

balance_mat[11,1] <- AvgBach$estimate[1]
balance_mat[11,2] <- AvgBach$estimate[2]
balance_mat[11,3] <- AvgBach$p.value

balance_mat[12,1] <- AvgMasters$estimate[1]
balance_mat[12,2] <- AvgMasters$estimate[2]
balance_mat[12,3] <- AvgMasters$p.value

balance_mat[13,1] <- AvgDoc$estimate[1]
balance_mat[13,2] <- AvgDoc$estimate[2]
balance_mat[13,3] <- AvgDoc$p.value

balance_mat

stargazer(balance_mat,
          type = "text",
          title = "Balance Tests")

# Average Treatment Effect (DONE) ---------------------------------------------------

view(pizzagate)

# This t.test isn't accurate because the randomization for the political party variable failed :(
# H0: There IS NO DIFFERENCE in believing fake news stories between the treatment and control groups
# H1: There IS A DIFFERENCE in believing fake news stories between the treatment and control groups
t.test(x = pizzagate$outcome[pizzagate$group==1],  # treatment group 
       y = pizzagate$outcome[pizzagate$group==0], # control group
       alternative = "two.sided") # we DO want to reject the null hypothesis
# p = 0.000000001276 -> there is a statistically significant difference in the mean
# being assigned to the treatment group had a 23% effect on whether the person DISAVOWED the content of the fake news story

view(results_pp)
results_pp$group <- factor(results_pp$group)

# Instead, we need to do a multiple linear regression including whether or not a respondent identifies as a "Not Strong Republican"
reg1 <- lm(outcome ~ group, data=results_pp)
summary(reg1) # this is the same as the t.test - p-value = 1.32e-09

# Let's do a second where we regress on whether the person is a NSR
reg2 <- lm(outcome ~ group + party_id_not_strong_republican, data=results_pp)
summary(reg2)

# p-value = (high) -> accept H0
# we have a LOW p-value which indicates strong evidence AGAINST the null hypothesis
# we are REJECTING the null hypothesis
# H0: There is NO DIFFERENCE in believing fake news stories between the treatment and control groups
# H1: There IS A DIFFERENCE in believing fake news stories between the treatment and control groups

stargazer(reg1,reg2,
          type = "text",
          title = "Average Treatment Effect of Fake News Corrections",
          notes.align="l",
          header = FALSE,
          model.names = FALSE,
          dep.var.labels.include = FALSE,
          dep.var.caption = "",
          keep.stat=c("adj.rsq","n"),
          covariate.labels = c("Treated", "Respondent Identified as Not Strong Republican", "Intercept"))

# We have estimated to a significantly significant level that there was a
# difference between treatment and control of about 23 percentage points
# When we include this in regression two, the treatment effect declines slightly
# to about 22.2 percentage points - this might be b/c of the failed randomization
# We can be relatively sure this is the case because we didn't lose any observations

# What does this mean?
# Being placed in the treatment group (getting exposed to corrections) increased
# the likelihood of the participant disagreeing or strongly disagreeing with the
# sentiment of the fake news story by around 22.2%.  This means that fact
# checking WORKS!!!!

# Visualization of the average treatment effect

# Make the treatment variable a factor
ggpredict(reg2,terms="group")
ATE <- ggpredict(reg2,terms="group")
plot(ATE, colors="breakfast.club") +
  ggtitle("Corrected Viewpoints by Respondent Group") +
  xlab("group") + ylab("disagreement")

# Thanks! :)
